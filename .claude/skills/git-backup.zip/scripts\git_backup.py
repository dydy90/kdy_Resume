#!/usr/bin/env python3
"""
Git Backup Script
Automates git workflow: status check, add, commit, and push
"""
import subprocess
import sys
import json
from datetime import datetime


def run_command(cmd, capture_output=True):
    """Run a shell command and return the result."""
    try:
        result = subprocess.run(
            cmd,
            shell=True,
            capture_output=capture_output,
            text=True,
            encoding='utf-8'
        )
        return result.returncode, result.stdout.strip(), result.stderr.strip()
    except Exception as e:
        return 1, "", str(e)


def check_git_status():
    """Check git status and return parsed information."""
    code, output, error = run_command("git status --porcelain")
    if code != 0:
        return None, f"Failed to check git status: {error}"
    return output.split('\n') if output else [], None


def stage_changes():
    """Stage all changes using git add."""
    code, output, error = run_command("git add .")
    if code != 0:
        return False, f"Failed to stage changes: {error}"
    return True, None


def get_staged_diff():
    """Get the diff of staged changes."""
    code, output, error = run_command("git diff --staged --stat")
    if code != 0:
        return None, f"Failed to get diff: {error}"
    return output, None


def create_commit(message):
    """Create a commit with the given message."""
    code, output, error = run_command(f'git commit -m "{message}"')
    if code != 0:
        return False, f"Failed to create commit: {error}"
    return True, output


def push_changes():
    """Push changes to remote repository."""
    code, output, error = run_command("git push")
    if code != 0:
        return False, f"Failed to push: {error}"
    return True, output


def generate_commit_message(diff_output):
    """Generate a commit message based on changes."""
    if not diff_output:
        return "chore: update files"

    # Simple commit message generation based on file types
    lines = diff_output.split('\n')
    changed_files = []
    for line in lines:
        if '|' in line:
            filename = line.split('|')[0].strip()
            changed_files.append(filename)

    if not changed_files:
        return "chore: update project files"

    # Categorize changes
    has_jsx = any(f.endswith('.jsx') or f.endswith('.js') for f in changed_files)
    has_css = any(f.endswith('.css') for f in changed_files)
    has_md = any(f.endswith('.md') for f in changed_files)
    has_sql = any(f.endswith('.sql') for f in changed_files)
    has_ts = any(f.endswith('.ts') or f.endswith('.tsx') for f in changed_files)

    if has_jsx or has_ts:
        return "feat: update frontend components"
    elif has_css:
        return "style: update styling"
    elif has_sql:
        return "db: update database schema"
    elif has_md:
        return "docs: update documentation"
    else:
        return "chore: update project files"


def main():
    """Main workflow execution."""
    commit_message = sys.argv[1] if len(sys.argv) > 1 else None

    # Step 1: Check git status
    print("Step 1: Checking git status...")
    status_lines, error = check_git_status()
    if error:
        print(json.dumps({"success": False, "error": error}, ensure_ascii=False))
        return 1

    if not status_lines or all(not line for line in status_lines):
        print(json.dumps({
            "success": True,
            "message": "No changes to commit. Working directory is clean."
        }, ensure_ascii=False))
        return 0

    print(f"Found {len([s for s in status_lines if s])} changed file(s).")

    # Step 2: Stage changes
    print("Step 2: Staging changes...")
    success, error = stage_changes()
    if not success:
        print(json.dumps({"success": False, "error": error}, ensure_ascii=False))
        return 1
    print("Changes staged successfully.")

    # Step 3: Review changes and create commit
    print("Step 3: Reviewing changes and creating commit...")
    diff_output, error = get_staged_diff()
    if error:
        print(json.dumps({"success": False, "error": error}, ensure_ascii=False))
        return 1

    print(f"Changes summary:\n{diff_output}")

    # Use provided message or generate one
    final_message = commit_message or generate_commit_message(diff_output)
    print(f"Commit message: {final_message}")

    success, error = create_commit(final_message)
    if not success:
        print(json.dumps({"success": False, "error": error}, ensure_ascii=False))
        return 1
    print("Commit created successfully.")

    # Step 4: Push to remote
    print("Step 4: Pushing to remote...")
    success, push_output = push_changes()
    if not success:
        print(json.dumps({"success": False, "error": push_output}, ensure_ascii=False))
        return 1
    print("Push completed successfully.")

    # Step 5: Report results
    result = {
        "success": True,
        "changes_summary": diff_output,
        "commit_message": final_message,
        "push_status": "success",
        "timestamp": datetime.now().isoformat()
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    main()
