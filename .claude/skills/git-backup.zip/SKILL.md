---
name: git-backup
description: Use this skill when the user says "백업해줘" (backup please) or requests to backup/push current changes to git. This skill automates the complete git workflow: check status, stage changes, create commit with appropriate message, and push to remote repository.
---

# Git Backup Skill

This skill automates the complete git backup workflow when the user requests a backup. It handles git status check, staging changes, creating commits, and pushing to remote repository.

## When to Use

Use this skill when the user says:
- "백업해줘" (backup please)
- "git 백업"
- "커밋하고 푸시해줘"
- "저장해줘" (in the context of git backup)

## Workflow

Execute the following steps in order:

### Step 1: Check Current Status

Run `git status` to check the current repository state.

### Step 2: Stage Changes

If there are uncommitted changes, run `git add .` to stage all changes.

### Step 3: Review Changes and Create Commit

1. Run `git diff --staged` to review staged changes
2. Based on the changes, create an appropriate commit message following the format:
   - If the user specified a message, use it
   - Otherwise, generate a descriptive commit message based on the changes
3. Run `git commit -m "<commit-message>"`

### Step 4: Push to Remote

Once the commit is created successfully, run `git push` to push changes to the remote repository.

### Step 5: Report Results

After the workflow completes, provide a summary including:
- Brief description of changes made
- The commit message that was used
- Push completion status (success/failure)

## Using the Backup Script

For efficient execution, use the bundled script at `scripts/git_backup.py`:

```bash
python .claude/skills/git-backup/scripts/git_backup.py [commit-message]
```

The script automatically handles the complete workflow and returns the required summary information.
